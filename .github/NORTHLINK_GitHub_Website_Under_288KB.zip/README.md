# NORTHLINK — Lango–Acholi Regional Development Network

## Upload these files to the ROOT of your GitHub repository
- `index.html`
- `assets/northlink-logo.webp`

Keep your existing `README.md` if you prefer.

## Publish with GitHub Pages
1. In your repository, choose Add file → Upload files.
2. Upload `index.html` to the repository root.
3. Create an `assets` folder in the repository and upload `northlink-logo.webp` into it.
4. Commit the changes to the `main` branch.
5. Open Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select `main` and `/(root)`, then Save.
8. After GitHub Pages publishes, your website URL will be:
   `https://YOUR-GITHUB-USERNAME.github.io/northlink-uganda/`

## Project status
This is a proposed initiative and prototype, not a registered organisation, funded programme, approved public service, or confirmed partnership. The 19 locations describe long-term proposed geographic scope, not immediate pilot coverage. The website does not provide a live opportunity database or operational referral service.
