NORTHLINK UGANDA — GitHub Pages upload package

Upload the contents of this folder to the ROOT of your northlink-uganda GitHub repository.

Required structure:
  index.html
  assets/
    northlink-logo.webp

Important:
- Keep the assets folder and the logo inside it; the website references assets/northlink-logo.webp.
- Do not upload the ZIP file itself expecting GitHub Pages to extract it.
- This is a proposed initiative prototype. Pilot locations are proposals for consultation, not confirmed selections.
